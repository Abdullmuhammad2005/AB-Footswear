const express = require('express');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const app = express();

mongoose.connect('mongodb:                                                                            

const userSchema = new mongoose.Schema({
  username: String,
  password: String
});

const loginRecordSchema = new mongoose.Schema({
  username: String,
  loginTime: Date
});

const User = mongoose.model('//localhost/userAuth', { useNewUrlParser: true, useUnifiedTopology: true });

const userSchema = new mongoose.Schema({
  username: String,
  password: String
});

const loginRecordSchema = new mongoose.Schema({
  username: String,
  loginTime: Date
});

const User = mongoose.model('User', userSchema);
const LoginRecord = mongoose.model('LoginRecord', loginRecordSchema);

app.use(express.json());

app.post('/sign-up', async (req, res) => {
  const { username, password } = req.body;
  const hashedPassword = await bcrypt.hash(password, 10);
  const user = new User({ username, password: hashedPassword });
  try {
    await user.save();
    res.send('User created successfully');
  } catch (err) {
    res.status(400).send(err.message);
  }
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) {
    return res.status(401).send('Invalid username or password');
  }
  const isValidPassword = await bcrypt.compare(password, user.password);
  if (!isValidPassword) {
    return res.status(401).send('Invalid username or password');
  }
  const token = jwt.sign({ username }, 'secretkey', { expiresIn: '1h' });
  const loginRecord = new LoginRecord({ username, loginTime: new Date() });
  try {
    await loginRecord.save();
    res.send({ token });
  } catch (err) {
    res.status(400).send(err.message);
  }
});

app.get('/login-records', async (req, res) => {
  try {
    const loginRecords = await LoginRecord.find().sort({ loginTime: -1 });
    res.send(loginRecords);
  } catch (err) {
    res.status(400).send(err.message);
  }
});

app.listen(3000, () => {
  console.log('Server listening on port 3000');
});