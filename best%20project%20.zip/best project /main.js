<script>
  const cartCount = document.getElementById('cart-count');
  let cart = JSON.parse(localStorage.getItem('cartItems')) || [];
  const buttons = document.querySelectorAll('.product-card button');
  const viewCartBtn = document.getElementById('view-cart-btn');

  function updateCartCount() {
    cartCount.textContent = cart.length;

    // Show or hide "View Cart" button with animation class
    if (cart.length > 0) {
      viewCartBtn.classList.add('show');
    } else {
      viewCartBtn.classList.remove('show');
    }
  }

  // Initial setup on page load
  updateCartCount();

  // Handle Add to Cart clicks
  buttons.forEach(button => {
    button.addEventListener('click', () => {
      const card = button.closest('.product-card');
      const name = card.querySelector('h3').textContent;
      const price = card.querySelector('p').textContent.replace('$', '');
      const image = card.querySelector('img').src;

      cart.push({ name, price, image });
      localStorage.setItem('cartItems', JSON.stringify(cart));
      updateCartCount();
    });
  });
  // Function to Show Custom Confirm Dialog
function customConfirm(message) {
  return new Promise((resolve) => {
    // Get Modal Elements
    const modal = document.getElementById('custom-confirm');
    const confirmMessage = document.getElementById('confirm-message');
    const yesButton = document.getElementById('confirm-yes');
    const noButton = document.getElementById('confirm-no');

    // Set the Message
    confirmMessage.textContent = message;

    // Show the Modal
    modal.classList.remove('hidden');

    // Event Listeners for Buttons
    yesButton.onclick = () => {
      modal.classList.add('hidden');
      resolve(true);
    };

    noButton.onclick = () => {
      modal.classList.add('hidden');
      resolve(false);
    };
  });
}

// Example Usage
document.getElementById('trigger').addEventListener('click', async () => {
  const userConfirmed = await customConfirm('Are you sure you want to delete this item?');
  if (userConfirmed) {
    // Proceed with deletion
    alert('Item deleted.');
  } else {
    // Cancellation logic
    alert('Deletion canceled.');
  }
});
// Load notifications from localStorage
function updateNotificationBadge() {
  const notifications = JSON.parse(localStorage.getItem('notifications')) || [];
  const unread = notifications.filter(n => !n.read).length;
  const badge = document.getElementById('notification-badge');
  badge.textContent = unread;
  badge.style.display = unread > 0 ? 'inline-block' : 'none';
}

// Call this on every page
document.addEventListener('DOMContentLoaded', updateNotificationBadge);
</script>
