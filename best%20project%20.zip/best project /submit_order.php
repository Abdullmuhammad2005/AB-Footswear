<?php
// Database configuration
$host = "localhost";
$dbname = "your_database";
$username = "your_user";
$password = "your_password";

// Create connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get POST data
$order_id = $_POST['order_id'];
$name = $_POST['name'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$message = $_POST['message'];
$items = $_POST['items'];
$total = $_POST['total'];
$date = $_POST['date'];
$delivery = $_POST['delivery'];
$status = "Processing";

// Prepare and execute SQL
$stmt = $conn->prepare("INSERT INTO orders (order_id, name, phone, address, message, items, total, date, estimated_delivery, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssssdsss", $order_id, $name, $phone, $address, $message, $items, $total, $date, $delivery, $status);

if ($stmt->execute()) {
  echo "success";
} else {
  echo "error";
}

$stmt->close();
$conn->close();
?>