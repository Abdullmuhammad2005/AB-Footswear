<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get user input
  $username = $_POST["username"];
  $password = $_POST["password"];

  // Connect to database (example)
  $conn = new mysqli("localhost", "user", "password", "database");

  // Check connection
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Prepare SQL statement (prevent SQL injection)
  $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? AND password = ?");
  $stmt->bind_param("ss", $username, $password);
  $stmt->execute();
  $result = $stmt->get_result();

  // Check if user exists
  if ($result->num_rows > 0) {
    // Start session
    session_start();
    $_SESSION["username"] = $username; // Store user information in session
    // Redirect to a protected page (e.g., dashboard)
    header("Location: dashboard.php");
  } else {
    // Display error message
    echo "Invalid username or password";
  }

  $stmt->close();
  $conn->close();
}
?>