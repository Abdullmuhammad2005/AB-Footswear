// OrderTrackingApp.jsx
import React, { useState, useEffect } from 'react';
import './App.css';

const mockOrders = [
  { id: 'ORD001', status: 'Order Placed' },
  { id: 'ORD002', status: 'Processing' },
  { id: 'ORD003', status: 'Shipped' },
  { id: 'ORD004', status: 'Delivered' },
];

const statusSteps = ['Order Placed', 'Processing', 'Shipped', 'Delivered'];

const App = () => {
  const [orders, setOrders] = useState([]);
  const [orderId, setOrderId] = useState('');
  const [currentStatus, setCurrentStatus] = useState('');
  const [theme, setTheme] = useState('light');

  useEffect(() => {
    // Simulate fetching real-time data
    setOrders(mockOrders);
  }, []);

  const handleTrack = () => {
    const found = orders.find(order => order.id === orderId.trim().toUpperCase());
    setCurrentStatus(found ? found.status : '');
  };

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  };

  return (
    <div className="app">
      <button id="theme-toggle" onClick={toggleTheme}>
        {theme === 'light' ? '🌙' : '☀️'}
      </button>

      <h1>Track Your Order</h1>

      <div className="tracker">
        <input
          type="text"
          placeholder="Enter Order ID"
          value={orderId}
          onChange={e => setOrderId(e.target.value)}
        />
        <button onClick={handleTrack}>Track</button>
      </div>

      {currentStatus ? (
        <ul className="steps">
          {statusSteps.map(step => (
            <li
              key={step}
              className={statusSteps.indexOf(step) <= statusSteps.indexOf(currentStatus) ? 'active' : ''}
            >
              {