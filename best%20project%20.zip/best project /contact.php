<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
  $name = $_POST["name"] ?? '';
  $email = $_POST["email"] ?? '';
  $message = $_POST["message"] ?? '';

  if ($name && $email && $message) {
    $to = "[email protected]"; // Change this to your actual email address
    $subject = "New Contact Message from $name";
    $headers = "From: $email\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    $body = "Name: $name\nEmail: $email\n\nMessage:\n$message";

    if (mail($to, $subject, $body, $headers)) {
      $status = "✅ Message sent successfully!";
    } else {
      $status = "❌ Failed to send the message.";
    }
  } else {
    $status = "❗ Please fill in all fields.";
  }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Form</title>
  <style>
    body { font-family: sans-serif; padding: 30px; background: #f5f5f5; }
    form { background: #fff; padding: 20px; max-width: 500px; margin: auto; border-radius: 8px; box-shadow: 0 0 10px #ccc; }
    input, textarea { width: 100%; margin: 10px 0; padding: 10px; font-size: 1rem; border: 1px solid #ccc; border-radius: 4px; }
    button { padding: 10px 20px; background: #333; color: #fff; border: none; cursor: pointer; border-radius: 4px; }
    .status { text-align: center; margin-top: 15px; font-weight: bold; }
  </style>
</head>
<body>

  <form method="POST" action="">
    <h2>Contact Us</h2>
    <input type="text" name="name" placeholder="Your Name" required />
    <input type="email" name="email" placeholder="Your Email" required />
    <textarea name="message" rows="5" placeholder="Your Message" required></textarea>
    <button type="submit">Send Message</button>
    <?php if (!empty($status)): ?>
      <div class="status"><?php echo htmlspecialchars($status); ?></div>
    <?php endif; ?>
  </form>

</body>
</html>